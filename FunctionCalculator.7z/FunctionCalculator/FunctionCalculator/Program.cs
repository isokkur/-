﻿using System;

namespace FunctionCalculator
{
    public class FunctionCalculator1 // Объявление класса FunctionCalculator1 для вычисления значения функции
    {
        public double CalculateFunctionValue(double x, double N)
        {
            if (x == N) // Проверка деления на 0 при равенстве x и N
            {
                throw new ArgumentException("Деление на 0: разрыв функции при x = N"); // Выброс исключения в случае деления на 0
            }
            return 1 / (x - N); // Вычисление значения функции
        }
    }

    class Program // Класс-приложение
    {
        static void Main(string[] args) // Главный метод Main приложения
        {
            double N = 5, k = 10; // Задание значений переменных N и k
            int iterations = 20; // Количество итераций (не используется в данном примере)

            FunctionCalculator1 calculator = new FunctionCalculator1(); // Создание экземпляра класса FunctionCalculator1

            for (double x = 0; x <= k; x += 0.1) // Цикл вычислений значений функции для различных x
            {
                try
                {
                    double result = calculator.CalculateFunctionValue(x, N); // Вычисление значения функции для конкретного x
                    Console.WriteLine("f({0}) = {1}", x, result); // Вывод результата на экран
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine("Произошло исключение: " + ex.Message); // Обработка исключения деления на 0
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Произошло исключение: " + ex.Message); // Обработка других исключений
                }
            }

            Console.WriteLine("Выполнение программы завершено."); // Вывод сообщения о завершении программы
        }
    }
}